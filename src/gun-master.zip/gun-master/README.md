Gun
===

STUN Server written in Google Go using the RCF 5389.



Missing Features
================
* Does not support ipv6
* Does not properly calculate starting rto
* Does not support the optional FINGERPRINT attribute


Most of these features can be added without too much difficulty but have not been needed yet as so are incomplete.