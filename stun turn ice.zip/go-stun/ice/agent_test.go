package ice

import (
	"testing"
)

func TestGathering(t *testing.T) {
}
