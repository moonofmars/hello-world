package turn

import (
	"testing"
)

func TestAllocate(t *testing.T) {
}
